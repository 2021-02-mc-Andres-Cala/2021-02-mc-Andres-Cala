/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B14
 */
public class Taller19 {

    public static void main(String[] args) {
        double Raizsy =0;
        double sumPromY = 0;
        double st= 0;
        double sy = 0;
        double syx = 0;
        double r = 0;
        double sumaX = 0;
        double sumaY = 0;
        double Xpow = 0;
        double XxY = 0;
        double promX = 0;
        double promY = 0;
        double[] x = {0,2,4,6,8,10,12};
        double[] y = {0.1,0.3,0.8,1.7,2.7,4.6,6.8};
        double a = 0;
        double a1 = 0;
        double sr = 0;
        

        for (int i = 0; i < x.length; i++) {
            sumaX += x[i];
            sumaY += y[i];
            XxY += (x[i] * y[i]);
            Xpow = Xpow + Math.pow(x[i], 2);
       
        }
        System.out.println("Sumatoria X= " + sumaX);
        System.out.println("Sumatoria Y= " + sumaY);
        System.out.println("Xpow(2)= " + Xpow);
        System.out.println("Sumatoria X*Y= " + XxY);
        promX = sumaX / x.length;
        System.out.println("promX= " + promX);
        promY = sumaY / x.length;
        System.out.println("promY= " + promY);
        a1 = (7 * (XxY) - (sumaX * sumaY)) / (7 * (Xpow) - (Math.pow(sumaX, 2)));
        System.out.println("a1= " + a1);
        a = promY - (a1 * promX);
        System.out.println("a= " + a);
        for (int i = 0; i < x.length; i++) {
          double mult = y[i]-promY;
          st = st + Math.pow(mult, 2);
       double mult2 = y[i]-a-a1*x[i];
        sr = sr + Math.pow(mult2, 2);
        }
        
        System.out.println("st = "+st);
        System.out.println("sr = "+sr);
        Raizsy = st/(x.length-1);
        sy= Math.pow(Raizsy,0.5);
        System.out.println("Sy = "+ sy);
        double Raizsyx = sr/(x.length-2);
        syx = Math.pow(Raizsyx, 0.5);
        System.out.println("syx = "+syx);
        double Raizr = ((st-sr)/(st));
        r = Math.pow(Raizr, 0.5);
       
        r=r*100;
         System.out.println("r= "+r);
        System.out.println("y= " + a + " + " + a1 + "x");

    }

}
