/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author B14
 */
public class Punto1 {

    public static void main(String[] args) {
        double sumaX = 0;
        double sumaY = 0;
        double Xpow = 0;
        double XxY = 0;
        double promX = 0;
        double promY = 0;
        double Alpha=0;
        double beta=0;
        double[] x = {1,2,3,4,5};
        double[] y = {1.7,3,4,4.6,5};
        double[] lnx = new double[x.length];
        double[] lny = new double[x.length];
        double a = 0;
        double a1 = 0;
        for (int i = 0; i < x.length; i++) {
            lnx[i]=Math.log10(x[i]);
            lny[i]=Math.log10(y[i]);
        }
        for (int i = 0; i < x.length; i++) {
            sumaX += lnx[i];
            sumaY += lny[i];
            XxY += (lnx[i] * lny[i]);
            Xpow = Xpow + Math.pow(lnx[i], 2);

        }
        System.out.println("Sumatoria X= " + sumaX);
        System.out.println("Sumatoria Y= " + sumaY);
        System.out.println("Xpow(2)= " + Xpow);
        System.out.println("Sumatoria X*Y= " + XxY);
        promX = sumaX / x.length;
        System.out.println("promX= " + promX);
        promY = sumaY / x.length;
        System.out.println("promY= " + promY);
        a1 = (x.length * (XxY) - (sumaX * sumaY)) / (x.length * (Xpow) - (Math.pow(sumaX, 2)));
        System.out.println("a1= " + a1);
        a = promY - (a1 * promX);
        System.out.println("a= " + a);
        Alpha=Math.pow(10, a);
        System.out.println("Alpha: " + Alpha);
        beta=a1;
        System.out.println("Beta: "+beta);
        System.out.println("y= " + Alpha + " * x^"+ beta);

    }
}
