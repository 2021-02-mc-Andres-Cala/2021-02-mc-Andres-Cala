/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parte22;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author B14
 */
public class Parte22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Hola, señor usuario escoja Las filas de la matriz");
        int A = sc.nextInt();
        System.out.println("\n");
        System.out.println("Hola, señor usuario escoja las columnas ");
        int B = sc.nextInt();
        int matriz1[][] = new int[A][B];
        
        //MATRIZ 1
        System.out.println("Matriz 1");
        for (int i = 0; i <= A - 1; i++) {
            for (int j = 0; j <= B - 1; j++) {
                matriz1[i][j] = (int) (Math.random() * 7 + 1);
            }
        }
        for (int i = 0; i <= A - 1; i++) {
            for (int j = 0; j <= B - 1; j++) {
                System.out.print(matriz1[i][j] + "\t");
            }
            System.out.println();

        }
        System.out.println("Hola, señor usuario escoja Las filas de la matriz 2");
        int C = sc.nextInt();
        System.out.println("\n");
        System.out.println("Hola, señor usuario escoja las columnas de la matriz 2");
        int D = sc.nextInt();
        
        //DECLARACION D EMATRICES
        
        int matriz2[][] = new int[C][D];
        int matrizPA [][] = new int [A][B] ;
        int matrizPB [][] = new int [C][D] ;
        int matrizT[][] = new int[C][D];        
        int matrizMult [][] = new int [A][D] ;
        //MATRIZ 2
        System.out.println("Matriz 2");
        for (int i = 0; i <= C - 1; i++) {
            for (int j = 0; j <= D - 1; j++) {
                matriz2[i][j] = (int) (Math.random() * 9 + 1);
            }
        }
        for (int i = 0; i <= C - 1 ; i++) {
            for (int j = 0; j <= D - 1 ; j++) {
                System.out.print(matriz2[i][j] + "\t");
            }
            System.out.println();

        }
        //MULTIPLICAION 3*A
        System.out.println("PUNTO 1 3*A :");
        
        for (int i = 0; i <= A - 1; i++) {
                for (int j = 0; j <= B - 1; j++) {
                    matrizPA[i][j] = 3*matriz1[i][j] ;
                    System.out.print(matrizPA[i][j] + " ");
                }
                System.out.println();
            }
        //Multiplicacion 4*B
                System.out.println("PUNTO 2 4*B :");

        
        for (int i = 0; i <= C - 1; i++) {
                for (int j = 0; j <= D - 1; j++) {
                    matrizPB[i][j] = 4*matriz2[i][j] ;
                    System.out.print(matrizPB[i][j] + " ");
                }
                System.out.println();
            }
        
        //SUMA DE A + B
                System.out.println("PUNTO 3 A+B :");

        if (A == C & B == D) {
            for (int i = 0; i <= C - 1; i++) {
                for (int j = 0; j <= D - 1; j++) {
                    matrizT[i][j] = matriz1[i][j] + matriz2[i][j];
                    System.out.print(matrizT[i][j] + " ");
                }
                System.out.println();
            }
        }else{
            System.out.println("Las matrices no pueden realizar esta operacion ya que tienen que ser de igual dimension");
        }
        //MUTPLICACION DE MATRICES
        System.out.println("PUNTO 4 B*A :");
        
        if (B == C) {
            for (int i = 0; i <= A - 1; i++) {
                for (int j = 0; j <= D - 1; j++) {
                    matrizMult[i][j] = matriz2[i][j]*matriz1[i][j]  ;
                    System.out.print(matrizMult[i][j] + " ");
                }
                System.out.println();
            }
        }else{
            System.out.println("Las matrices no pueden realizar esta operacion ya que no cumple la condicion");
        }
    }
}
