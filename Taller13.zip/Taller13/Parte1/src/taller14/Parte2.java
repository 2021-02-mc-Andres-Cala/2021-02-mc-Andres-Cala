/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller14;

import java.util.Scanner;

/**
 *
 * @author B14
 */
public class Parte2 {
    public static void main(String[] args) {
                Scanner sc = new Scanner(System.in);

        System.out.println("Hola, señor usuario escoja Las filas de la matriz");
        int A = sc.nextInt();
        System.out.println("\n");
        System.out.println("Hola, señor usuario escoja las columnas ");
        int B = sc.nextInt();
        int matriz[][] = new int [A][B] ;
    for (int i=0; i < A-1; i++) {
        for(int j=0 ; j<B-1; j++){
             matriz[i][j] =(int)(Math.random()*7+1);
        }
  }
    }
}
