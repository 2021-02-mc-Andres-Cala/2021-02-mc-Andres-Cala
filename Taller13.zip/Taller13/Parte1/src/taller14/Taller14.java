/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller14;

import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author B14
 */
public class Taller14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Hola, señor usuario escoja la longitud del primer vector");
        int Vec1 = sc.nextInt();
        System.out.println("\n");
        System.out.println("Hola, señor usuario escoja la longitud del segundo vector");
        int Vec2 = sc.nextInt();
        
        int [] m1= new int [Vec1] ;
        for (int i=0; i < m1.length; i++) {
            m1[i] = (int)(Math.random()*7+1);
  
  }
           System.out.println(" El vector A es:"+ Arrays.toString(m1)); 
           int [] m2= new int [Vec2] ;
        for (int i=0; i < m2.length; i++) {
            m2[i] = (int)(Math.random()*9+1);
  
  }
           System.out.println(" El vector A es:"+ Arrays.toString(m2));
           int escalar= 0;
          if(Vec1 == Vec2){
               for (int o=0;o<Vec1;o++){
                 
                 escalar = escalar + (m1[o] * m2[o]);
               }
               System.out.println("La multiplicacion es : " + escalar);
           }else{
               System.out.println("Los vectores no tienen las mismas dimensiones");
           }
           
}
}
    

