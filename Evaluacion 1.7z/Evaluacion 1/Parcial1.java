/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parcial1;

import java.util.HashSet;

/**
 *
 * @author B14
 */
public class Parcial1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Lista A
        HashSet<Integer> A = new HashSet<>();
        A.add(1);
        A.add(3);
        A.add(5);
        A.add(7);
        A.add(11);
        A.add(22);
        A.add(44);
        System.out.println("Lista A" + A);
        //lista B
        HashSet<Integer> B = new HashSet<>();
        for (int i = 5; i < 25; i++) {
            B.add(i);

        }
        System.out.println("Lista B" + B);
        //Lista C
        HashSet<Integer> C = new HashSet<>();
        for (int i = 1; i <= 30; i++) {
            if (i % 3 == 1) {
                C.add(i);
            }
        }
        System.out.println("Lista C" + C);
        //Lista D
        HashSet<Integer> D = new HashSet<>();
        D.add(2);
        D.add(3);
        D.add(5);
        D.add(7);
        D.add(11);
        D.add(13);
        D.add(17);
        D.add(19);
        D.add(23);
        D.add(29);
        D.add(31);
        D.add(37);
        D.add(41);
        D.add(43);
        D.add(47);

        System.out.println("Lista D" + D);
        //Primera operacion
        HashSet<Integer> Ope1 = Diferencia(interseccion(A, D), DifSim(B, C));
        System.out.println("Operacion 1" + Ope1);
        //Segunda operacion
        HashSet<Integer> Ope2 = interseccion(DifSim(A, D), Diferencia(union(B, C), A));
        System.out.println("Operacion 2" + Ope2);
        HashSet<Integer> Ope3 = Diferencia(DifSim(interseccion(B, C), union(A, D)), union(union(B, C), A));
        System.out.println("Operacion 3 " + Ope3);
    }

    public static HashSet<Integer> union(HashSet<Integer> c1, HashSet<Integer> c2) {
        HashSet<Integer> resultado = new HashSet<>();
        resultado.addAll(c1);
        resultado.addAll(c2);
        return resultado;

    }

    public static HashSet<Integer> interseccion(HashSet<Integer> c1, HashSet<Integer> c2) {
        HashSet<Integer> resultado = new HashSet<>();
        for (int elemento : c1) {
            if (c2.contains(elemento)) {
                resultado.add(elemento);

            }
        }

        return resultado;

    }

    public static HashSet<Integer> Diferencia(HashSet<Integer> c1, HashSet<Integer> c2) {
        HashSet<Integer> resultado = new HashSet<>();
        for (int elemento : c1) {
            if (!c2.contains(elemento)) {
                resultado.add(elemento);

            }

        }
        for (int elemento : c2) {
            if (!c1.contains(elemento)) {
                resultado.add(elemento);
            }
        }
        return resultado;

    }

    public static HashSet<Integer> DifSim(HashSet<Integer> c1, HashSet<Integer> c2) {
        HashSet<Integer> resultado = Diferencia(union(c1, c2), interseccion(c1, c2));

        return resultado;

    }

}
