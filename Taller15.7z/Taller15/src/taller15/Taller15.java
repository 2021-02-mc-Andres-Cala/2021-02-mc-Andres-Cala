/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller15;

/**
 *
 * @author B14
 */
public class Taller15 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        
      double[][] a = {{3, 1, 1},
        {1, 0, -3},
        {5, 2, -5}};
        double[][] b = {{1, 0, 0},
        {0, 1, 0},
        {0, 0, 1}};
        System.out.println("Matriz original");
        imprimirSistema(a,b);
        System.out.println("Matriz identidad");
        
        for (int i = 0; i < a.length; i++) {
            double pivote = a[i][i];
            if(pivote == 0){
                for (int l = i + 1 ; l <a.length; l++){
                    if(a[l][i] !=0){
                        double[] renglonAux = a[i];
                        a[i] = a[l];
                        a[l] = renglonAux;
                        double[] ValorAux = b[i];
                        b[i]= b[l];
                        b[l]= ValorAux;
                        
                        pivote = a[i][i];
                        break;
                    }
                }
            }
            
            if (pivote != 1) {
                for (int j = 0; j < a[i].length; j++) {
                    a[i][j] = a[i][j] / pivote;
                }
                for (int j = 0; j < a[i].length; j++) {
                    b[i][j] = b[i][j] / pivote;
                }
                
                System.out.println("Pivoteo");
                imprimirSistema(a,b);
                
            } else {
                System.out.println("No requiere pivoteo");
            }
            
            //reduccion
            for (int l = 0; l <a.length ; l++){
                if( i != l){
                    double multiplicador = a[l][i];
                    for (int j = 0; j<a[l].length; j++){
                        a[l][j] = a[l][j] - multiplicador * a[i][j];
                    }
                    for (int j = 0; j<a[l].length; j++){
                        b[l][j] = b[l][j] - multiplicador * b[i][j];
                    }

                    
                }
            }
            System.out.println("Reduccion");
            imprimirSistema (a,b);
            
        }
    }

    private static void imprimirSistema(double[][] a, double[][] b) {
        for (int i = 0; i < a.length ; i++) {
            for (int j = 0; j <a[i].length ; j++) {
                System.out.print(a[i][j] + "    ");
            }
            System.out.print(" | ");
            for (int j = 0; j <b[i].length ; j++) {
                System.out.print(b[i][j] + "    ");
            }
            System.out.println("\n");
            
        }
    }
}


