/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package taller14;

/**
 *
 * @author B14
 */
public class Taylor {
    
    public static void main(String[] args){
        double xi = 0.62;
        double xi1 = 0.625;
        double h = xi1 - xi;
        double fxi1 = 0;
        int signo = 1;
        double ea= 100;
        for (int i = 0; i <= 15; i++){
            double fxAnt = fxi1;
            fxi1= fxi1 + Math.exp(-xi)*Math.pow(h, i) / factorial(i);
            ea = Math.abs((fxi1 - fxAnt)/fxi1) * 100;
            System.out.println("Orden " + i );
            System.out.println("f(x) = " + fxi1 );
            System.out.println("ea= " + ea + "%");
        }
    }
    private static double factorial (int n){
        double x = 1;
        for (int i = 2; i <=n; i++){
        x = x * i;
        }
        return x;
    }
}
